# Telegram Bot Setup

এই বটটি চালাতে আপনার Python ইনস্টল থাকা লাগবে।

## কিভাবে চালাবেন:

1. প্রথমে Python ইনস্টল করুন (যদি না থাকে): https://www.python.org/downloads/
2. কমান্ড লাইনে গিয়ে নিচের কমান্ড দিন:

```bash
pip install -r requirements.txt
python bot.py
```

## কাজ কী করে?
- `/start` বা `/help` দিলে বট অভ্যর্থনা জানাবে
- যেকোনো বার্তা দিলে সেই বার্তার রিপ্লাই দিবে

Enjoy your bot!
