import telebot

API_TOKEN = "7554688568:AAFW-dxij8t1Jr-MKDbZBUCcl1XRTYNG8QE"
bot = telebot.TeleBot(API_TOKEN)

@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    bot.reply_to(message, "হ্যালো! আমি একটি সিম্পল টেলিগ্রাম বট। আমাকে কিছু বলো, আমি রিপ্লাই দেবো।")

@bot.message_handler(func=lambda message: True)
def echo_all(message):
    bot.reply_to(message, message.text)

bot.infinity_polling()
